import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, boolean, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userTypeEnum = pgEnum('user_type', ['student', 'shop_owner']);
export const bookingStatusEnum = pgEnum('booking_status', ['pending', 'confirmed', 'active', 'completed', 'cancelled']);
export const vehicleTypeEnum = pgEnum('vehicle_type', ['bike', 'scooter', 'electric']);
export const campusLocationEnum = pgEnum('campus_location', ['bidholi', 'kandoli', 'near_campus']);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email"),
  phone: text("phone"),
  name: text("name").notNull(),
  userType: userTypeEnum("user_type").notNull().default('student'),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const shops = pgTable("shops", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  location: campusLocationEnum("location").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  rating: decimal("rating", { precision: 3, scale: 2 }).default('0.00'),
  totalReviews: integer("total_reviews").default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bikes = pgTable("bikes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shopId: varchar("shop_id").references(() => shops.id).notNull(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  model: text("model").notNull(),
  vehicleType: vehicleTypeEnum("vehicle_type").notNull(),
  engineCapacity: text("engine_capacity"),
  fuelType: text("fuel_type"),
  transmission: text("transmission"),
  hourlyRate: decimal("hourly_rate", { precision: 8, scale: 2 }).notNull(),
  dailyRate: decimal("daily_rate", { precision: 8, scale: 2 }),
  weeklyRate: decimal("weekly_rate", { precision: 8, scale: 2 }),
  rating: decimal("rating", { precision: 3, scale: 2 }).default('0.00'),
  totalReviews: integer("total_reviews").default(0),
  isAvailable: boolean("is_available").notNull().default(true),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  bikeId: varchar("bike_id").references(() => bikes.id).notNull(),
  shopId: varchar("shop_id").references(() => shops.id).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalHours: integer("total_hours").notNull(),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  status: bookingStatusEnum("status").notNull().default('pending'),
  paymentStatus: text("payment_status").default('pending'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const otpVerifications = pgTable("otp_verifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email"),
  phone: text("phone"),
  otp: text("otp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  shops: many(shops),
  bookings: many(bookings),
}));

export const shopsRelations = relations(shops, ({ one, many }) => ({
  owner: one(users, { fields: [shops.ownerId], references: [users.id] }),
  bikes: many(bikes),
  bookings: many(bookings),
}));

export const bikesRelations = relations(bikes, ({ one, many }) => ({
  shop: one(shops, { fields: [bikes.shopId], references: [shops.id] }),
  bookings: many(bookings),
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  user: one(users, { fields: [bookings.userId], references: [users.id] }),
  bike: one(bikes, { fields: [bookings.bikeId], references: [bikes.id] }),
  shop: one(shops, { fields: [bookings.shopId], references: [shops.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertShopSchema = createInsertSchema(shops).omit({
  id: true,
  createdAt: true,
  rating: true,
  totalReviews: true,
});

export const insertBikeSchema = createInsertSchema(bikes).omit({
  id: true,
  createdAt: true,
  rating: true,
  totalReviews: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOTPSchema = createInsertSchema(otpVerifications).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Shop = typeof shops.$inferSelect;
export type InsertShop = z.infer<typeof insertShopSchema>;

export type Bike = typeof bikes.$inferSelect;
export type InsertBike = z.infer<typeof insertBikeSchema>;

export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;

export type OTPVerification = typeof otpVerifications.$inferSelect;
export type InsertOTP = z.infer<typeof insertOTPSchema>;
