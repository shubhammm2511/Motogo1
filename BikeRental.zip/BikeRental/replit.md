# MotoGo - Bike Rental Service for UPES Campus

## Overview

MotoGo is a full-stack bike rental service designed specifically for UPES Bidholi and Kandoli campus students. The platform connects students with local bike rental shops, offering a seamless booking experience through OTP-based authentication. Students can browse available bikes, filter by location and preferences, and book rentals instantly. Shop owners can register their businesses, manage their bike inventory, and track bookings through dedicated dashboards.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type safety and modern component patterns
- **Wouter** for client-side routing, providing a lightweight alternative to React Router
- **Tailwind CSS** with custom design system using CSS variables for consistent theming
- **Shadcn/ui** component library for accessible, customizable UI components
- **TanStack Query** for server state management, caching, and data synchronization
- **Vite** as the build tool for fast development and optimized production builds

### Backend Architecture
- **Express.js** server with TypeScript for type-safe backend development
- **Drizzle ORM** with PostgreSQL for database operations and schema management
- **JWT-based authentication** with secure token handling and middleware protection
- **OTP verification system** using email (Nodemailer) for passwordless authentication
- **RESTful API design** with proper error handling and HTTP status codes

### Database Design
- **PostgreSQL** with Neon serverless for scalable database hosting
- **Drizzle schema** with proper relationships between users, shops, bikes, and bookings
- **Type-safe database queries** with Drizzle's query builder
- **Migration system** for schema versioning and deployment

### Authentication & Authorization
- **OTP-based authentication** eliminates password complexity for student users
- **Role-based access control** distinguishing between students and shop owners
- **JWT token management** with secure storage and automatic refresh handling
- **Protected routes** using authentication middleware

### State Management
- **Client-side caching** with TanStack Query for optimized data fetching
- **Local storage integration** for authentication persistence
- **Real-time availability updates** through query invalidation
- **Optimistic updates** for improved user experience

## External Dependencies

### Database & Infrastructure
- **Neon PostgreSQL** - Serverless PostgreSQL database hosting
- **Drizzle Kit** - Database migration and schema management tool

### Authentication Services
- **Nodemailer** - Email service for OTP delivery
- **JWT (jsonwebtoken)** - Token generation and verification

### UI & Styling
- **Radix UI** - Accessible primitive components for complex UI elements
- **Tailwind CSS** - Utility-first CSS framework with custom design tokens
- **Lucide React** - Icon library with consistent iconography

### Development Tools
- **TypeScript** - Type safety across the entire stack
- **Vite** - Development server and build tool
- **ESBuild** - Fast JavaScript bundler for production builds

### Third-party Integrations
- **Replit-specific plugins** - Development environment integration
- **Email SMTP services** - Configurable email providers for OTP delivery
- **Image hosting services** - External URLs for bike and shop images

### Campus-Specific Features
- **Location-based filtering** - Bidholi and Kandoli campus targeting
- **Student-friendly pricing** - Hourly, daily, and weekly rate structures
- **Mobile-responsive design** - Optimized for student mobile usage patterns