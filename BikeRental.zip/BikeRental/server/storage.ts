import { 
  users, shops, bikes, bookings, otpVerifications,
  type User, type InsertUser,
  type Shop, type InsertShop,
  type Bike, type InsertBike,
  type Booking, type InsertBooking,
  type OTPVerification, type InsertOTP
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lte, like, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;

  // Shop operations
  getShop(id: string): Promise<Shop | undefined>;
  getShopsByLocation(location: string): Promise<Shop[]>;
  getShopsByOwner(ownerId: string): Promise<Shop[]>;
  createShop(shop: InsertShop): Promise<Shop>;
  updateShop(id: string, updates: Partial<InsertShop>): Promise<Shop>;
  getAllShops(): Promise<Shop[]>;

  // Bike operations
  getBike(id: string): Promise<Bike | undefined>;
  getBikesByShop(shopId: string): Promise<Bike[]>;
  getBikesWithFilters(filters: {
    location?: string;
    vehicleType?: string;
    minPrice?: number;
    maxPrice?: number;
    available?: boolean;
  }): Promise<(Bike & { shop: Shop })[]>;
  createBike(bike: InsertBike): Promise<Bike>;
  updateBike(id: string, updates: Partial<InsertBike>): Promise<Bike>;
  getAllBikes(): Promise<(Bike & { shop: Shop })[]>;

  // Booking operations
  getBooking(id: string): Promise<Booking | undefined>;
  getBookingsByUser(userId: string): Promise<(Booking & { bike: Bike; shop: Shop })[]>;
  getBookingsByShop(shopId: string): Promise<(Booking & { bike: Bike; user: User })[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, updates: Partial<InsertBooking>): Promise<Booking>;
  checkBikeAvailability(bikeId: string, startDate: Date, endDate: Date): Promise<boolean>;

  // OTP operations
  createOTP(otp: InsertOTP): Promise<OTPVerification>;
  getOTP(email?: string, phone?: string): Promise<OTPVerification | undefined>;
  markOTPAsUsed(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  // Shop operations
  async getShop(id: string): Promise<Shop | undefined> {
    const [shop] = await db.select().from(shops).where(eq(shops.id, id));
    return shop || undefined;
  }

  async getShopsByLocation(location: string): Promise<Shop[]> {
    return await db.select().from(shops).where(eq(shops.location, location as any));
  }

  async getShopsByOwner(ownerId: string): Promise<Shop[]> {
    return await db.select().from(shops).where(eq(shops.ownerId, ownerId));
  }

  async createShop(insertShop: InsertShop): Promise<Shop> {
    const [shop] = await db.insert(shops).values(insertShop).returning();
    return shop;
  }

  async updateShop(id: string, updates: Partial<InsertShop>): Promise<Shop> {
    const [shop] = await db.update(shops).set(updates).where(eq(shops.id, id)).returning();
    return shop;
  }

  async getAllShops(): Promise<Shop[]> {
    return await db.select().from(shops).where(eq(shops.isActive, true));
  }

  // Bike operations
  async getBike(id: string): Promise<Bike | undefined> {
    const [bike] = await db.select().from(bikes).where(eq(bikes.id, id));
    return bike || undefined;
  }

  async getBikesByShop(shopId: string): Promise<Bike[]> {
    return await db.select().from(bikes).where(eq(bikes.shopId, shopId));
  }

  async getBikesWithFilters(filters: {
    location?: string;
    vehicleType?: string;
    minPrice?: number;
    maxPrice?: number;
    available?: boolean;
  }): Promise<(Bike & { shop: Shop })[]> {
    const conditions = [];

    if (filters.available !== undefined) {
      conditions.push(eq(bikes.isAvailable, filters.available));
    }
    if (filters.vehicleType) {
      conditions.push(eq(bikes.vehicleType, filters.vehicleType as any));
    }
    if (filters.minPrice) {
      conditions.push(gte(bikes.hourlyRate, filters.minPrice.toString()));
    }
    if (filters.maxPrice) {
      conditions.push(lte(bikes.hourlyRate, filters.maxPrice.toString()));
    }
    if (filters.location) {
      conditions.push(eq(shops.location, filters.location as any));
    }

    const result = await db
      .select()
      .from(bikes)
      .innerJoin(shops, eq(bikes.shopId, shops.id))
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    return result.map(row => ({ ...row.bikes, shop: row.shops }));
  }

  async createBike(insertBike: InsertBike): Promise<Bike> {
    const [bike] = await db.insert(bikes).values(insertBike).returning();
    return bike;
  }

  async updateBike(id: string, updates: Partial<InsertBike>): Promise<Bike> {
    const [bike] = await db.update(bikes).set(updates).where(eq(bikes.id, id)).returning();
    return bike;
  }

  async getAllBikes(): Promise<(Bike & { shop: Shop })[]> {
    const result = await db
      .select()
      .from(bikes)
      .innerJoin(shops, eq(bikes.shopId, shops.id))
      .where(eq(bikes.isAvailable, true));

    return result.map(row => ({ ...row.bikes, shop: row.shops }));
  }

  // Booking operations
  async getBooking(id: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking || undefined;
  }

  async getBookingsByUser(userId: string): Promise<(Booking & { bike: Bike; shop: Shop })[]> {
    const result = await db
      .select()
      .from(bookings)
      .innerJoin(bikes, eq(bookings.bikeId, bikes.id))
      .innerJoin(shops, eq(bookings.shopId, shops.id))
      .where(eq(bookings.userId, userId))
      .orderBy(desc(bookings.createdAt));

    return result.map(row => ({ ...row.bookings, bike: row.bikes, shop: row.shops }));
  }

  async getBookingsByShop(shopId: string): Promise<(Booking & { bike: Bike; user: User })[]> {
    const result = await db
      .select()
      .from(bookings)
      .innerJoin(bikes, eq(bookings.bikeId, bikes.id))
      .innerJoin(users, eq(bookings.userId, users.id))
      .where(eq(bookings.shopId, shopId))
      .orderBy(desc(bookings.createdAt));

    return result.map(row => ({ ...row.bookings, bike: row.bikes, user: row.users }));
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db.insert(bookings).values(insertBooking).returning();
    return booking;
  }

  async updateBooking(id: string, updates: Partial<InsertBooking>): Promise<Booking> {
    const [booking] = await db.update(bookings).set(updates).where(eq(bookings.id, id)).returning();
    return booking;
  }

  async checkBikeAvailability(bikeId: string, startDate: Date, endDate: Date): Promise<boolean> {
    const conflictingBookings = await db
      .select()
      .from(bookings)
      .where(
        and(
          eq(bookings.bikeId, bikeId),
          sql`${bookings.startDate} < ${endDate}`,
          sql`${bookings.endDate} > ${startDate}`,
          sql`${bookings.status} IN ('confirmed', 'active')`
        )
      );

    return conflictingBookings.length === 0;
  }

  // OTP operations
  async createOTP(insertOTP: InsertOTP): Promise<OTPVerification> {
    const [otp] = await db.insert(otpVerifications).values(insertOTP).returning();
    return otp;
  }

  async getOTP(email?: string, phone?: string): Promise<OTPVerification | undefined> {
    let condition;
    if (email) {
      condition = eq(otpVerifications.email, email);
    } else if (phone) {
      condition = eq(otpVerifications.phone, phone);
    } else {
      return undefined;
    }

    const [otp] = await db
      .select()
      .from(otpVerifications)
      .where(and(condition, eq(otpVerifications.isUsed, false)))
      .orderBy(desc(otpVerifications.createdAt))
      .limit(1);

    return otp || undefined;
  }

  async markOTPAsUsed(id: string): Promise<void> {
    await db.update(otpVerifications).set({ isUsed: true }).where(eq(otpVerifications.id, id));
  }
}

export const storage = new DatabaseStorage();
