import { db } from "./db";
import { users, shops, bikes } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database...");

  try {
    // Create shop owners
    const [owner1] = await db.insert(users).values({
      email: 'owner1@motogo.com',
      name: 'Rajesh Kumar',
      userType: 'shop_owner',
      isVerified: true,
    }).returning();

    const [owner2] = await db.insert(users).values({
      email: 'owner2@motogo.com',
      name: 'Priya Sharma',
      userType: 'shop_owner',
      isVerified: true,
    }).returning();

    // Create sample student
    await db.insert(users).values({
      email: 'student@upes.ac.in',
      name: 'Arjun Singh',
      userType: 'student',
      isVerified: true,
    }).returning();

    // Create shops near UPES campus
    const [shop1] = await db.insert(shops).values({
      ownerId: owner1.id,
      name: 'Campus Wheels',
      description: 'Premium bike rentals near UPES Bidholi campus with latest models and affordable rates.',
      location: 'bidholi',
      address: 'Shop No. 15, Main Road, Near UPES Bidholi Gate, Bidholi, Dehradun - 248007',
      phone: '+91 9876543210',
      latitude: '30.3498405',
      longitude: '78.0640734',
      rating: '4.8',
      totalReviews: 89,
      isActive: true,
    }).returning();

    const [shop2] = await db.insert(shops).values({
      ownerId: owner2.id,
      name: 'Kandoli Bike Zone',
      description: 'Your trusted partner for bike rentals at UPES Kandoli campus. Electric and petrol bikes available.',
      location: 'kandoli',
      address: 'Plot No. 42, Transport Nagar, Near UPES Kandoli Campus, Kandoli, Dehradun - 248001',
      phone: '+91 8765432109',
      latitude: '30.3673',
      longitude: '78.0669',
      rating: '4.6',
      totalReviews: 76,
      isActive: true,
    }).returning();

    const [shop3] = await db.insert(shops).values({
      ownerId: owner1.id,
      name: 'Student Ride Hub',
      description: 'Premium bikes and scooters for UPES students. Special student discounts available.',
      location: 'near_campus',
      address: 'Sector 12, Patel Nagar, Between Bidholi & Kandoli Campus, Dehradun - 248140',
      phone: '+91 7654321098',
      latitude: '30.3585',
      longitude: '78.0655',
      rating: '4.9',
      totalReviews: 124,
      isActive: true,
    }).returning();

    // Create bikes for Campus Wheels (Bidholi)
    await db.insert(bikes).values([
      {
        shopId: shop1.id,
        name: 'Honda CB Shine',
        brand: 'Honda',
        model: 'CB Shine',
        vehicleType: 'bike',
        engineCapacity: '125cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '55.00',
        dailyRate: '400.00',
        weeklyRate: '2500.00',
        rating: '4.7',
        totalReviews: 89,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop1.id,
        name: 'TVS Apache RTR 160',
        brand: 'TVS',
        model: 'Apache RTR 160',
        vehicleType: 'bike',
        engineCapacity: '160cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '70.00',
        dailyRate: '500.00',
        weeklyRate: '3200.00',
        rating: '4.6',
        totalReviews: 65,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop1.id,
        name: 'Hero Splendor Plus',
        brand: 'Hero',
        model: 'Splendor Plus',
        vehicleType: 'bike',
        engineCapacity: '100cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '45.00',
        dailyRate: '320.00',
        weeklyRate: '2000.00',
        rating: '4.4',
        totalReviews: 112,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
    ]);

    // Create bikes for Kandoli Bike Zone
    await db.insert(bikes).values([
      {
        shopId: shop2.id,
        name: 'Yamaha Fascino',
        brand: 'Yamaha',
        model: 'Fascino',
        vehicleType: 'scooter',
        engineCapacity: '125cc',
        fuelType: 'Petrol',
        transmission: 'Automatic',
        hourlyRate: '45.00',
        dailyRate: '350.00',
        weeklyRate: '2200.00',
        rating: '4.5',
        totalReviews: 76,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop2.id,
        name: 'Honda Activa 6G',
        brand: 'Honda',
        model: 'Activa 6G',
        vehicleType: 'scooter',
        engineCapacity: '110cc',
        fuelType: 'Petrol',
        transmission: 'Automatic',
        hourlyRate: '50.00',
        dailyRate: '380.00',
        weeklyRate: '2400.00',
        rating: '4.3',
        totalReviews: 94,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop2.id,
        name: 'Ola S1 Pro',
        brand: 'Ola',
        model: 'S1 Pro',
        vehicleType: 'electric',
        engineCapacity: 'Electric',
        fuelType: 'Electric',
        transmission: 'Automatic',
        hourlyRate: '60.00',
        dailyRate: '450.00',
        weeklyRate: '2800.00',
        rating: '4.7',
        totalReviews: 58,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
    ]);

    // Create bikes for Student Ride Hub
    await db.insert(bikes).values([
      {
        shopId: shop3.id,
        name: 'Royal Enfield Classic 350',
        brand: 'Royal Enfield',
        model: 'Classic 350',
        vehicleType: 'bike',
        engineCapacity: '350cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '90.00',
        dailyRate: '650.00',
        weeklyRate: '4200.00',
        rating: '4.8',
        totalReviews: 124,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop3.id,
        name: 'Ather 450X',
        brand: 'Ather',
        model: '450X',
        vehicleType: 'electric',
        engineCapacity: 'Electric',
        fuelType: 'Electric',
        transmission: 'Automatic',
        hourlyRate: '75.00',
        dailyRate: '550.00',
        weeklyRate: '3500.00',
        rating: '4.9',
        totalReviews: 45,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop3.id,
        name: 'KTM Duke 200',
        brand: 'KTM',
        model: 'Duke 200',
        vehicleType: 'bike',
        engineCapacity: '200cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '85.00',
        dailyRate: '600.00',
        weeklyRate: '3800.00',
        rating: '4.6',
        totalReviews: 73,
        isAvailable: true,
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
      {
        shopId: shop3.id,
        name: 'Bajaj Pulsar NS200',
        brand: 'Bajaj',
        model: 'Pulsar NS200',
        vehicleType: 'bike',
        engineCapacity: '200cc',
        fuelType: 'Petrol',
        transmission: 'Manual',
        hourlyRate: '80.00',
        dailyRate: '580.00',
        weeklyRate: '3600.00',
        rating: '4.5',
        totalReviews: 87,
        isAvailable: false, // One bike not available
        imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300',
      },
    ]);

    console.log("Database seeded successfully!");
    console.log("Created:");
    console.log("- 3 users (2 shop owners, 1 student)");
    console.log("- 3 shops (Campus Wheels, Kandoli Bike Zone, Student Ride Hub)");
    console.log("- 10 bikes across all shops");
    
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log("Seeding completed successfully");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Seeding failed:", error);
      process.exit(1);
    });
}

export { seedDatabase };
