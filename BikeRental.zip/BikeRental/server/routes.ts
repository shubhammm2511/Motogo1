import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertShopSchema, insertBikeSchema, insertBookingSchema } from "@shared/schema";
import { authService } from "./services/authService";
import { emailService } from "./services/emailService";
import { smsService } from "./services/smsService";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const verifyToken = async (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.status(401).json({ message: "Invalid token" });
    }
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid token" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/send-otp", async (req, res) => {
    try {
      const { email, phone } = req.body;
      
      if (!email && !phone) {
        return res.status(400).json({ message: "Email or phone number is required" });
      }

      const otp = authService.generateOTP();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      await storage.createOTP({
        email,
        phone,
        otp,
        expiresAt,
      });

      if (email) {
        await emailService.sendOTP(email, otp);
      } else if (phone) {
        await smsService.sendOTP(phone, otp);
      }

      res.json({ message: "OTP sent successfully" });
    } catch (error) {
      console.error("Send OTP error:", error);
      res.status(500).json({ message: "Failed to send OTP" });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { email, phone, otp, name, userType } = req.body;
      
      const otpRecord = await storage.getOTP(email, phone);
      
      if (!otpRecord || otpRecord.otp !== otp || otpRecord.expiresAt < new Date()) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
      }

      await storage.markOTPAsUsed(otpRecord.id);

      // Check if user exists
      let user = email 
        ? await storage.getUserByEmail(email)
        : await storage.getUserByPhone(phone!);

      if (!user) {
        // Create new user
        user = await storage.createUser({
          email,
          phone,
          name: name || "User",
          userType: userType || "student",
          isVerified: true,
        });
      } else {
        // Update verification status
        user = await storage.updateUser(user.id, { isVerified: true });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET);
      
      res.json({ 
        message: "OTP verified successfully",
        token,
        user: { id: user.id, name: user.name, email: user.email, userType: user.userType }
      });
    } catch (error) {
      console.error("Verify OTP error:", error);
      res.status(500).json({ message: "Failed to verify OTP" });
    }
  });

  // User routes
  app.get("/api/users/profile", verifyToken, async (req: any, res) => {
    try {
      res.json(req.user);
    } catch (error) {
      console.error("Get profile error:", error);
      res.status(500).json({ message: "Failed to get profile" });
    }
  });

  // Shop routes
  app.get("/api/shops", async (req, res) => {
    try {
      const { location } = req.query;
      
      const shops = location 
        ? await storage.getShopsByLocation(location as string)
        : await storage.getAllShops();
      
      res.json(shops);
    } catch (error) {
      console.error("Get shops error:", error);
      res.status(500).json({ message: "Failed to get shops" });
    }
  });

  app.post("/api/shops", verifyToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'shop_owner') {
        return res.status(403).json({ message: "Only shop owners can create shops" });
      }

      const shopData = insertShopSchema.parse({ ...req.body, ownerId: req.user.id });
      const shop = await storage.createShop(shopData);
      
      res.status(201).json(shop);
    } catch (error) {
      console.error("Create shop error:", error);
      res.status(500).json({ message: "Failed to create shop" });
    }
  });

  app.get("/api/shops/my-shops", verifyToken, async (req: any, res) => {
    try {
      const shops = await storage.getShopsByOwner(req.user.id);
      res.json(shops);
    } catch (error) {
      console.error("Get my shops error:", error);
      res.status(500).json({ message: "Failed to get shops" });
    }
  });

  // Bike routes
  app.get("/api/bikes", async (req, res) => {
    try {
      const filters = {
        location: req.query.location as string,
        vehicleType: req.query.vehicleType as string,
        minPrice: req.query.minPrice ? parseFloat(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined,
        available: req.query.available === 'true',
      };

      const bikes = await storage.getBikesWithFilters(filters);
      res.json(bikes);
    } catch (error) {
      console.error("Get bikes error:", error);
      res.status(500).json({ message: "Failed to get bikes" });
    }
  });

  app.get("/api/bikes/:id", async (req, res) => {
    try {
      const bike = await storage.getBike(req.params.id);
      if (!bike) {
        return res.status(404).json({ message: "Bike not found" });
      }
      res.json(bike);
    } catch (error) {
      console.error("Get bike error:", error);
      res.status(500).json({ message: "Failed to get bike" });
    }
  });

  app.post("/api/bikes", verifyToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'shop_owner') {
        return res.status(403).json({ message: "Only shop owners can add bikes" });
      }

      const bikeData = insertBikeSchema.parse(req.body);
      
      // Verify shop ownership
      const shop = await storage.getShop(bikeData.shopId);
      if (!shop || shop.ownerId !== req.user.id) {
        return res.status(403).json({ message: "You can only add bikes to your own shops" });
      }

      const bike = await storage.createBike(bikeData);
      res.status(201).json(bike);
    } catch (error) {
      console.error("Create bike error:", error);
      res.status(500).json({ message: "Failed to create bike" });
    }
  });

  app.get("/api/bikes/shop/:shopId", async (req, res) => {
    try {
      const bikes = await storage.getBikesByShop(req.params.shopId);
      res.json(bikes);
    } catch (error) {
      console.error("Get shop bikes error:", error);
      res.status(500).json({ message: "Failed to get shop bikes" });
    }
  });

  // Booking routes
  app.post("/api/bookings", verifyToken, async (req: any, res) => {
    try {
      const bookingData = insertBookingSchema.parse({ ...req.body, userId: req.user.id });
      
      // Check bike availability
      const isAvailable = await storage.checkBikeAvailability(
        bookingData.bikeId,
        bookingData.startDate,
        bookingData.endDate
      );

      if (!isAvailable) {
        return res.status(400).json({ message: "Bike is not available for the selected time period" });
      }

      const booking = await storage.createBooking(bookingData);
      
      // Update bike availability if booking is immediate
      if (bookingData.startDate <= new Date()) {
        await storage.updateBike(bookingData.bikeId, { isAvailable: false });
      }

      res.status(201).json(booking);
    } catch (error) {
      console.error("Create booking error:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.get("/api/bookings/my-bookings", verifyToken, async (req: any, res) => {
    try {
      const bookings = await storage.getBookingsByUser(req.user.id);
      res.json(bookings);
    } catch (error) {
      console.error("Get user bookings error:", error);
      res.status(500).json({ message: "Failed to get bookings" });
    }
  });

  app.get("/api/bookings/shop/:shopId", verifyToken, async (req: any, res) => {
    try {
      // Verify shop ownership
      const shop = await storage.getShop(req.params.shopId);
      if (!shop || shop.ownerId !== req.user.id) {
        return res.status(403).json({ message: "You can only view bookings for your own shops" });
      }

      const bookings = await storage.getBookingsByShop(req.params.shopId);
      res.json(bookings);
    } catch (error) {
      console.error("Get shop bookings error:", error);
      res.status(500).json({ message: "Failed to get shop bookings" });
    }
  });

  app.patch("/api/bookings/:id", verifyToken, async (req: any, res) => {
    try {
      const booking = await storage.getBooking(req.params.id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      // Check permissions
      if (booking.userId !== req.user.id) {
        const shop = await storage.getShop(booking.shopId);
        if (!shop || shop.ownerId !== req.user.id) {
          return res.status(403).json({ message: "You can only update your own bookings or shop bookings" });
        }
      }

      const updatedBooking = await storage.updateBooking(req.params.id, req.body);
      
      // Update bike availability if status changes
      if (req.body.status === 'completed' || req.body.status === 'cancelled') {
        await storage.updateBike(booking.bikeId, { isAvailable: true });
      }

      res.json(updatedBooking);
    } catch (error) {
      console.error("Update booking error:", error);
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
