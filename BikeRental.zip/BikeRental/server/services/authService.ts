import crypto from 'crypto';

class AuthService {
  generateOTP(): string {
    return crypto.randomInt(100000, 999999).toString();
  }

  generateToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }
}

export const authService = new AuthService();
