import nodemailer from 'nodemailer';

class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || process.env.EMAIL_USER || 'your-email@gmail.com',
        pass: process.env.SMTP_PASS || process.env.EMAIL_PASS || 'your-email-password',
      },
    });
  }

  async sendOTP(email: string, otp: string): Promise<void> {
    const mailOptions = {
      from: process.env.SMTP_USER || process.env.EMAIL_USER || 'noreply@motogo.com',
      to: email,
      subject: 'MotoGo - Your OTP Verification Code',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #F59E0B; margin: 0;">MotoGo</h1>
            <p style="color: #6B7280; margin: 5px 0 0 0;">Your Ride, Your Way</p>
          </div>
          
          <div style="background-color: #F59E0B; padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 20px;">
            <h2 style="color: #1F2937; margin: 0 0 10px 0;">Verification Code</h2>
            <div style="background-color: white; padding: 20px; border-radius: 8px; display: inline-block;">
              <span style="font-size: 32px; font-weight: bold; color: #1F2937; letter-spacing: 4px;">${otp}</span>
            </div>
          </div>
          
          <div style="background-color: #F9FAFB; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <p style="margin: 0; color: #374151;">
              Enter this code to verify your account. This code will expire in <strong>10 minutes</strong>.
            </p>
          </div>
          
          <div style="text-align: center; color: #6B7280; font-size: 14px;">
            <p>If you didn't request this code, please ignore this email.</p>
            <p style="margin-top: 20px;">
              © 2024 MotoGo. Made with ❤️ for UPES students.
            </p>
          </div>
        </div>
      `,
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log(`OTP email sent to ${email}`);
    } catch (error) {
      console.error('Failed to send OTP email:', error);
      throw new Error('Failed to send OTP email');
    }
  }
}

export const emailService = new EmailService();
