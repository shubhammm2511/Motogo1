class SMSService {
  private accountSid: string;
  private authToken: string;
  private fromNumber: string;

  constructor() {
    this.accountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.authToken = process.env.TWILIO_AUTH_TOKEN || '';
    this.fromNumber = process.env.TWILIO_PHONE_NUMBER || '';
  }

  async sendOTP(phone: string, otp: string): Promise<void> {
    if (!this.accountSid || !this.authToken || !this.fromNumber) {
      throw new Error('Twilio credentials not configured');
    }

    // Format phone number to include country code if not present
    const formattedPhone = phone.startsWith('+') ? phone : `+91${phone}`;

    try {
      // Using Twilio REST API directly instead of SDK to avoid dependency issues
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${this.accountSid}:${this.authToken}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: this.fromNumber,
          To: formattedPhone,
          Body: `MotoGo Verification Code: ${otp}\n\nEnter this code to verify your account. Code expires in 10 minutes.\n\nIf you didn't request this, please ignore this message.`
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Twilio SMS error:', errorData);
        throw new Error(`SMS service error: ${errorData.message || 'Failed to send SMS'}`);
      }

      const result = await response.json();
      console.log(`OTP SMS sent to ${formattedPhone}, Message SID: ${result.sid}`);
    } catch (error) {
      console.error('Failed to send OTP SMS:', error);
      throw new Error('Failed to send OTP via SMS');
    }
  }
}

export const smsService = new SMSService();