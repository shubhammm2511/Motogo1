import { User, Shop, Bike, Booking } from "@shared/schema";

export type BikeWithShop = Bike & {
  shop: Shop;
};

export type BookingWithDetails = Booking & {
  bike: Bike;
  shop: Shop;
  user?: User;
};

export type ShopWithStats = Shop & {
  bikeCount?: number;
  activeBookings?: number;
};

export interface SearchFilters {
  location: string;
  vehicleType: string;
  minPrice: string;
  maxPrice: string;
  available: boolean;
}

export interface AuthUser {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  userType: 'student' | 'shop_owner';
}

export { User, Shop, Bike, Booking };
