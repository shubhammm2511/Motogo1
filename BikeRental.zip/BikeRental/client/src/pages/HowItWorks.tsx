import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Search, MessageSquare, CreditCard, MapPin, Clock, Shield } from "lucide-react";

export default function HowItWorks() {
  const [, setLocation] = useLocation();

  const steps = [
    {
      icon: <Search className="w-8 h-8 text-primary" />,
      title: "1. Browse & Search",
      description: "Find bikes and scooters near your campus location. Filter by type, price, and availability."
    },
    {
      icon: <MessageSquare className="w-8 h-8 text-primary" />,
      title: "2. Verify via OTP",
      description: "Quick sign-up with your email or phone number. No passwords needed - just simple OTP verification."
    },
    {
      icon: <CreditCard className="w-8 h-8 text-primary" />,
      title: "3. Book & Pay",
      description: "Select your rental duration and pay securely. Get instant confirmation with pickup details."
    }
  ];

  const features = [
    {
      icon: <MapPin className="w-6 h-6 text-secondary" />,
      title: "Campus Locations",
      description: "Available at UPES Bidholi, Kandoli, and nearby areas"
    },
    {
      icon: <Clock className="w-6 h-6 text-secondary" />,
      title: "Flexible Timing",
      description: "Hourly, daily, or weekly rentals to fit your schedule"
    },
    {
      icon: <Shield className="w-6 h-6 text-secondary" />,
      title: "Safe & Verified",
      description: "All bikes are verified and maintained by trusted local partners"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            How MotoGo Works
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Renting a bike or scooter has never been easier. Get moving in just three simple steps.
          </p>
        </div>

        {/* Steps Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {steps.map((step, index) => (
            <Card key={index} className="text-center h-full">
              <CardHeader className="pb-4">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                    {step.icon}
                  </div>
                </div>
                <CardTitle className="text-xl">{step.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Features Section */}
        <div className="bg-accent/30 rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Why Choose MotoGo?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center">
                    {feature.icon}
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-primary rounded-2xl p-8">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Ready to Get Moving?
          </h2>
          <p className="text-primary-foreground/80 text-lg mb-6">
            Join hundreds of UPES students who trust MotoGo for their daily commute.
          </p>
          <Button 
            size="lg"
            variant="secondary"
            onClick={() => setLocation('/browse')}
            className="bg-white text-primary hover:bg-gray-100"
            data-testid="button-browse-bikes"
          >
            Browse Available Bikes
          </Button>
        </div>
      </div>
    </div>
  );
}