import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import SearchFilters from "@/components/SearchFilters";
import BikeCard from "@/components/BikeCard";
import { Skeleton } from "@/components/ui/skeleton";
import { BikeWithShop } from "@/types";

export default function BrowseBikes() {
  const [filters, setFilters] = useState({
    location: 'all',
    vehicleType: 'all',
    minPrice: '',
    maxPrice: '',
    available: true,
  });

  const { data: bikes, isLoading, error } = useQuery<BikeWithShop[]>({
    queryKey: ['/api/bikes', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== '' && value !== null && value !== undefined && value !== 'all') {
          params.append(key, value.toString());
        }
      });
      
      const response = await fetch(`/api/bikes?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch bikes');
      return response.json();
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Browse Bikes</h1>
          <p className="text-muted-foreground">Find the perfect ride for your needs</p>
        </div>

        <SearchFilters filters={filters} onFiltersChange={setFilters} />

        {error && (
          <div className="text-center py-12">
            <p className="text-destructive">Failed to load bikes. Please try again.</p>
          </div>
        )}

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-48 w-full rounded-2xl" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-10 w-full" />
              </div>
            ))}
          </div>
        ) : (
          <>
            {bikes && bikes.length > 0 ? (
              <>
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">
                    {bikes.length} bikes found
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {bikes.map((bike) => (
                    <BikeCard key={bike.id} bike={bike} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-lg font-semibold text-foreground mb-2">No bikes found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your filters to see more results
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
