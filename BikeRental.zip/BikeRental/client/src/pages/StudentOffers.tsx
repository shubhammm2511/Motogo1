import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { GraduationCap, Star, Gift, Users, Percent, Trophy } from "lucide-react";

export default function StudentOffers() {
  const [, setLocation] = useLocation();

  const studentOffers = [
    {
      title: "New Student Welcome",
      discount: "50% OFF",
      code: "WELCOME50",
      description: "First ride free for new UPES students",
      icon: <GraduationCap className="w-8 h-8 text-primary" />,
      validity: "Valid for first booking only",
      terms: "Valid for rides up to 2 hours",
      popular: true
    },
    {
      title: "Weekly Student Pass",
      discount: "30% OFF", 
      code: "STUDENT30",
      description: "Weekly rentals at student-friendly prices",
      icon: <Star className="w-8 h-8 text-primary" />,
      validity: "Valid on all weekly bookings",
      terms: "Show valid student ID",
      popular: false
    },
    {
      title: "Friend Referral Bonus",
      discount: "₹100 Cash",
      code: "REFER100",
      description: "Earn ₹100 for every friend you refer",
      icon: <Users className="w-8 h-8 text-primary" />,
      validity: "Both you and friend get ₹100",
      terms: "Friend must complete first ride",
      popular: false
    }
  ];

  const seasonalOffers = [
    {
      title: "Exam Season Special",
      period: "November - December",
      discount: "25% OFF",
      description: "Stress-free commute during exam season",
      icon: <Trophy className="w-6 h-6 text-secondary" />
    },
    {
      title: "Monsoon Offer",
      period: "July - September", 
      discount: "Free Rain Cover",
      description: "Complimentary rain protection gear",
      icon: <Gift className="w-6 h-6 text-secondary" />
    },
    {
      title: "Festival Rides",
      period: "Festival Seasons",
      discount: "Buy 2 Get 1",
      description: "Extra day free on 3-day bookings",
      icon: <Percent className="w-6 h-6 text-secondary" />
    }
  ];

  const loyaltyBenefits = [
    "Priority booking during peak hours",
    "Free bike maintenance and cleaning",
    "Extended rental hours at no extra cost",
    "Access to premium bikes at regular rates",
    "Birthday month special discount",
    "Semester exam period discounts"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Exclusive Student Offers
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Being a UPES student has its perks! Enjoy special discounts and offers designed just for you.
          </p>
        </div>

        {/* Active Student Offers */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Current Student Offers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {studentOffers.map((offer, index) => (
              <Card key={index} className={`relative h-full ${offer.popular ? 'ring-2 ring-primary' : ''}`}>
                {offer.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-4">
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                      {offer.icon}
                    </div>
                  </div>
                  <CardTitle className="text-xl">{offer.title}</CardTitle>
                  <div className="mt-2">
                    <span className="text-2xl font-bold text-primary">{offer.discount}</span>
                  </div>
                  <p className="text-muted-foreground mt-2">{offer.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-accent/50 p-3 rounded-lg text-center">
                    <p className="text-sm font-medium">Promo Code</p>
                    <p className="text-lg font-bold text-primary">{offer.code}</p>
                  </div>
                  <div className="text-sm space-y-2">
                    <p><strong>Validity:</strong> {offer.validity}</p>
                    <p><strong>Terms:</strong> {offer.terms}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Seasonal Offers */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Seasonal Offers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {seasonalOffers.map((offer, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 bg-secondary/20 rounded-full flex items-center justify-center">
                      {offer.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{offer.title}</CardTitle>
                      <p className="text-sm text-muted-foreground">{offer.period}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-lg font-semibold text-primary">{offer.discount}</p>
                    <p className="text-muted-foreground">{offer.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Loyalty Program */}
        <div className="bg-accent/30 rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Student Loyalty Benefits</h2>
          <p className="text-center text-muted-foreground mb-8">
            The more you ride with MotoGo, the more you save! Regular students enjoy these exclusive benefits:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {loyaltyBenefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-3">
                <Star className="w-5 h-5 text-primary flex-shrink-0" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* How to Claim */}
        <div className="bg-primary rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-primary-foreground text-center mb-6">
            How to Claim Your Student Discount
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-primary-foreground">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">1</span>
              </div>
              <h3 className="font-semibold mb-2">Verify Student Status</h3>
              <p className="text-primary-foreground/80">Use your UPES email address during registration</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">2</span>
              </div>
              <h3 className="font-semibold mb-2">Apply Promo Code</h3>
              <p className="text-primary-foreground/80">Enter the offer code during checkout</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">3</span>
              </div>
              <h3 className="font-semibold mb-2">Enjoy Your Ride</h3>
              <p className="text-primary-foreground/80">Save money while exploring campus and beyond</p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Save on Your Next Ride?</h2>
          <p className="text-muted-foreground text-lg mb-6">
            Join thousands of UPES students who are already saving with MotoGo.
          </p>
          <Button 
            size="lg"
            onClick={() => setLocation('/browse')}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            data-testid="button-claim-offers"
          >
            Browse Bikes & Claim Offers
          </Button>
        </div>
      </div>
    </div>
  );
}