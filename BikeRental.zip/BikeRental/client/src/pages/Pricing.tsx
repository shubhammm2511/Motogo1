import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Check, Clock, Calendar, Users } from "lucide-react";

export default function Pricing() {
  const [, setLocation] = useLocation();

  const pricingPlans = [
    {
      title: "Hourly",
      icon: <Clock className="w-6 h-6" />,
      price: "₹45-90",
      period: "per hour",
      description: "Perfect for quick trips and short commutes",
      features: [
        "All bike types available",
        "Flexible timing",
        "No commitment",
        "Instant booking"
      ],
      popular: false
    },
    {
      title: "Daily",
      icon: <Calendar className="w-6 h-6" />,
      price: "₹300-600",
      period: "per day",
      description: "Best for full-day exploration or multiple trips",
      features: [
        "Up to 12 hours usage",
        "Better value than hourly",
        "Perfect for campus events",
        "Priority booking"
      ],
      popular: true
    },
    {
      title: "Weekly",
      icon: <Users className="w-6 h-6" />,
      price: "₹1,800-3,500",
      period: "per week",
      description: "Maximum savings for regular commuters",
      features: [
        "7 days unlimited usage",
        "Biggest savings",
        "Ideal for regular commute",
        "Free bike maintenance"
      ],
      popular: false
    }
  ];

  const bikeTypes = [
    {
      type: "Regular Bikes",
      hourly: "₹45-60",
      daily: "₹300-400",
      weekly: "₹1,800-2,400",
      features: ["Manual gear", "Standard mileage", "Easy to ride"]
    },
    {
      type: "Scooters",
      hourly: "₹60-75",
      daily: "₹400-500",
      weekly: "₹2,400-3,000",
      features: ["Automatic", "Good mileage", "Storage space"]
    },
    {
      type: "Electric Bikes",
      hourly: "₹75-90",
      daily: "₹500-600",
      weekly: "₹3,000-3,500",
      features: ["Eco-friendly", "Silent operation", "Low running cost"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose the rental duration that works best for you. All prices include maintenance and basic insurance.
          </p>
        </div>

        {/* Pricing Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {pricingPlans.map((plan, index) => (
            <Card key={index} className={`relative h-full ${plan.popular ? 'ring-2 ring-primary' : ''}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                    {plan.icon}
                  </div>
                </div>
                <CardTitle className="text-2xl">{plan.title}</CardTitle>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-primary">{plan.price}</span>
                  <span className="text-muted-foreground"> {plan.period}</span>
                </div>
                <p className="text-muted-foreground mt-2">{plan.description}</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-4 h-4 text-secondary mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bike Types Pricing */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Pricing by Vehicle Type</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {bikeTypes.map((bike, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-xl">{bike.type}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Hourly</span>
                      <span className="font-semibold">{bike.hourly}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Daily</span>
                      <span className="font-semibold">{bike.daily}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Weekly</span>
                      <span className="font-semibold">{bike.weekly}</span>
                    </div>
                    <div className="pt-4 border-t">
                      <p className="text-sm text-muted-foreground mb-2">Features:</p>
                      <ul className="text-sm space-y-1">
                        {bike.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center">
                            <Check className="w-3 h-3 text-secondary mr-2" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-primary rounded-2xl p-8">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Start Your Journey Today
          </h2>
          <p className="text-primary-foreground/80 text-lg mb-6">
            No hidden fees, no deposits required. Pay only for what you use.
          </p>
          <Button 
            size="lg"
            variant="secondary"
            onClick={() => setLocation('/browse')}
            className="bg-white text-primary hover:bg-gray-100"
            data-testid="button-start-booking"
          >
            Start Booking Now
          </Button>
        </div>
      </div>
    </div>
  );
}