import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { auth } from "@/lib/auth";
import { BikeWithShop } from "@/types";
import { MapPin, Clock, Fuel, Settings } from "lucide-react";
import Navigation from "@/components/Navigation";

export default function BookingPage() {
  const { bikeId } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [bookingData, setBookingData] = useState({
    startDate: '',
    endDate: '',
    startTime: '',
    endTime: '',
  });

  const { data: bike, isLoading } = useQuery<BikeWithShop>({
    queryKey: ['/api/bikes', bikeId],
    queryFn: async () => {
      const response = await fetch(`/api/bikes/${bikeId}`);
      if (!response.ok) throw new Error('Failed to fetch bike details');
      return response.json();
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/bookings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: "Your bike rental has been booked successfully",
      });
      setLocation('/dashboard');
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking",
        variant: "destructive",
      });
    },
  });

  const calculateTotalPrice = () => {
    if (!bookingData.startDate || !bookingData.endDate || !bike) {
      return 0;
    }

    const start = new Date(`${bookingData.startDate}T${bookingData.startTime || '00:00'}`);
    const end = new Date(`${bookingData.endDate}T${bookingData.endTime || '23:59'}`);
    const hours = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60));
    
    return hours * parseFloat(bike.hourlyRate);
  };

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!auth.getToken()) {
      toast({
        title: "Login Required",
        description: "Please login to book a bike",
        variant: "destructive",
      });
      setLocation('/login');
      return;
    }

    if (!bookingData.startDate || !bookingData.endDate) {
      toast({
        title: "Invalid Dates",
        description: "Please select valid start and end dates",
        variant: "destructive",
      });
      return;
    }

    const start = new Date(`${bookingData.startDate}T${bookingData.startTime || '00:00'}`);
    const end = new Date(`${bookingData.endDate}T${bookingData.endTime || '23:59'}`);
    const hours = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60));

    if (hours <= 0) {
      toast({
        title: "Invalid Duration",
        description: "End date must be after start date",
        variant: "destructive",
      });
      return;
    }

    createBookingMutation.mutate({
      bikeId: bikeId,
      shopId: bike?.shopId,
      startDate: start.toISOString(),
      endDate: end.toISOString(),
      totalHours: hours,
      totalPrice: calculateTotalPrice(),
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="h-64 bg-muted rounded"></div>
            <div className="h-32 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!bike) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Bike Not Found</h1>
          <Button onClick={() => setLocation('/browse')} data-testid="button-back-browse">
            Back to Browse
          </Button>
        </div>
      </div>
    );
  }

  const totalPrice = calculateTotalPrice();
  const totalHours = bookingData.startDate && bookingData.endDate 
    ? Math.ceil((new Date(`${bookingData.endDate}T${bookingData.endTime || '23:59'}`).getTime() - 
                 new Date(`${bookingData.startDate}T${bookingData.startTime || '00:00'}`).getTime()) / (1000 * 60 * 60))
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/browse')} 
          className="mb-6"
          data-testid="button-back"
        >
          ← Back to Browse
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Bike Details */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-0">
                <img 
                  src={bike.imageUrl || "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300"} 
                  alt={`${bike.brand} ${bike.model}`}
                  className="w-full h-64 object-cover rounded-t-lg"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h1 className="text-2xl font-bold text-foreground">{bike.brand} {bike.model}</h1>
                    {bike.isAvailable ? (
                      <Badge className="bg-accent text-accent-foreground">Available</Badge>
                    ) : (
                      <Badge variant="destructive">Not Available</Badge>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Settings className="w-4 h-4" />
                      <span>{bike.engineCapacity}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Fuel className="w-4 h-4" />
                      <span>{bike.fuelType}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Settings className="w-4 h-4" />
                      <span>{bike.transmission}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{bike.shop?.name}</span>
                    </div>
                  </div>

                  <div className="text-center py-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-foreground">₹{bike.hourlyRate}</div>
                    <div className="text-sm text-muted-foreground">per hour</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Booking Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Book This Bike</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBooking} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={bookingData.startDate}
                        onChange={(e) => setBookingData({ ...bookingData, startDate: e.target.value })}
                        min={new Date().toISOString().split('T')[0]}
                        required
                        data-testid="input-start-date"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="startTime">Start Time</Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={bookingData.startTime}
                        onChange={(e) => setBookingData({ ...bookingData, startTime: e.target.value })}
                        data-testid="input-start-time"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="endDate">End Date</Label>
                      <Input
                        id="endDate"
                        type="date"
                        value={bookingData.endDate}
                        onChange={(e) => setBookingData({ ...bookingData, endDate: e.target.value })}
                        min={bookingData.startDate || new Date().toISOString().split('T')[0]}
                        required
                        data-testid="input-end-date"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endTime">End Time</Label>
                      <Input
                        id="endTime"
                        type="time"
                        value={bookingData.endTime}
                        onChange={(e) => setBookingData({ ...bookingData, endTime: e.target.value })}
                        data-testid="input-end-time"
                      />
                    </div>
                  </div>

                  <Separator />

                  {totalHours > 0 && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span>{totalHours} hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Rate:</span>
                        <span>₹{bike.hourlyRate}/hour</span>
                      </div>
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total:</span>
                        <span data-testid="text-total-price">₹{totalPrice}</span>
                      </div>
                    </div>
                  )}

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={!bike.isAvailable || createBookingMutation.isPending || totalPrice === 0}
                    data-testid="button-book-now"
                  >
                    {createBookingMutation.isPending ? 'Booking...' : `Book Now - ₹${totalPrice}`}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
