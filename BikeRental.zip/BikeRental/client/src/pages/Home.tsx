import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import PopularShops from "@/components/PopularShops";
import FeaturedBikes from "@/components/FeaturedBikes";
import Features from "@/components/Features";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <PopularShops />
      <FeaturedBikes />
      <Features />
      <Footer />
    </div>
  );
}
