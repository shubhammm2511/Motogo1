import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { auth } from "@/lib/auth";
import { Store } from "lucide-react";
import Navigation from "@/components/Navigation";

export default function ShopRegistration() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = auth.getUser();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    location: '' as 'bidholi' | 'kandoli' | 'near_campus' | '',
    address: '',
    phone: '',
  });

  if (!user || user.userType !== 'shop_owner') {
    setLocation('/login');
    return null;
  }

  const createShopMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/shops', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Shop Registered!",
        description: "Your shop has been successfully registered",
      });
      setLocation('/shop-dashboard');
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to register shop",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.location || !formData.address || !formData.phone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    createShopMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Store className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Register Your Shop</h1>
          <p className="text-muted-foreground">Join the MotoGo network and start renting your bikes</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Shop Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Shop Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your shop name"
                  required
                  data-testid="input-shop-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe your shop and services"
                  rows={3}
                  data-testid="textarea-description"
                />
              </div>

              <div className="space-y-2">
                <Label>Campus Location *</Label>
                <Select value={formData.location} onValueChange={(value: 'bidholi' | 'kandoli' | 'near_campus') => setFormData({ ...formData, location: value })}>
                  <SelectTrigger data-testid="select-location">
                    <SelectValue placeholder="Select campus location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bidholi">UPES Bidholi</SelectItem>
                    <SelectItem value="kandoli">UPES Kandoli</SelectItem>
                    <SelectItem value="near_campus">Near Campus</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Complete Address *</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Enter your shop's complete address"
                  rows={2}
                  required
                  data-testid="textarea-address"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Contact Phone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+91 9876543210"
                  required
                  data-testid="input-phone"
                />
              </div>

              <div className="bg-muted/50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">What's Next?</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Your shop will be reviewed for approval</li>
                  <li>• You can start adding bikes immediately</li>
                  <li>• Students can discover and book your bikes</li>
                  <li>• Track all bookings in your dashboard</li>
                </ul>
              </div>

              <div className="flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setLocation('/shop-dashboard')}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={createShopMutation.isPending}
                  data-testid="button-register"
                >
                  {createShopMutation.isPending ? 'Registering...' : 'Register Shop'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
