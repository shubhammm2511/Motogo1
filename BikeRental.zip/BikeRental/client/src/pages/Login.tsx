import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { auth } from "@/lib/auth";
import { Bike } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState<'contact' | 'otp' | 'details'>('contact');
  const [contactType, setContactType] = useState<'email' | 'phone'>('email');
  const [contactValue, setContactValue] = useState('');
  const [otp, setOtp] = useState('');
  const [userDetails, setUserDetails] = useState({
    name: '',
    userType: 'student' as 'student' | 'shop_owner'
  });

  const sendOTPMutation = useMutation({
    mutationFn: async (data: { email?: string; phone?: string }) => {
      const response = await apiRequest('POST', '/api/auth/send-otp', data);
      return response.json();
    },
    onSuccess: () => {
      setStep('otp');
      toast({
        title: "OTP Sent",
        description: `Verification code sent to your ${contactType}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send OTP",
        variant: "destructive",
      });
    },
  });

  const verifyOTPMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/auth/verify-otp', data);
      return response.json();
    },
    onSuccess: (data) => {
      auth.setToken(data.token);
      auth.setUser(data.user);
      toast({
        title: "Welcome!",
        description: "Successfully logged in",
      });
      
      if (data.user.userType === 'shop_owner') {
        setLocation('/shop-dashboard');
      } else {
        setLocation('/dashboard');
      }
    },
    onError: (error: any) => {
      toast({
        title: "Invalid OTP",
        description: error.message || "Please check your verification code",
        variant: "destructive",
      });
    },
  });

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactValue) return;

    const data = contactType === 'email' 
      ? { email: contactValue }
      : { phone: contactValue };
    
    sendOTPMutation.mutate(data);
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;

    const data = {
      [contactType]: contactValue,
      otp,
      name: userDetails.name,
      userType: userDetails.userType,
    };

    verifyOTPMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Bike className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Welcome to MotoGo</h1>
          <p className="text-muted-foreground">Your Ride, Your Way</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-center">
              {step === 'contact' && 'Enter your details'}
              {step === 'otp' && 'Verify your account'}
              {step === 'details' && 'Complete your profile'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {step === 'contact' && (
              <form onSubmit={handleSendOTP} className="space-y-4">
                <div className="space-y-2">
                  <Label>Contact Method</Label>
                  <Select value={contactType} onValueChange={(value: 'email' | 'phone') => setContactType(value)}>
                    <SelectTrigger data-testid="select-contact-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>{contactType === 'email' ? 'Email Address' : 'Phone Number'}</Label>
                  <Input
                    type={contactType === 'email' ? 'email' : 'tel'}
                    placeholder={contactType === 'email' ? 'your.email@upes.ac.in' : '+91 9876543210'}
                    value={contactValue}
                    onChange={(e) => setContactValue(e.target.value)}
                    required
                    data-testid="input-contact"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    type="text"
                    placeholder="Enter your full name"
                    value={userDetails.name}
                    onChange={(e) => setUserDetails({ ...userDetails, name: e.target.value })}
                    required
                    data-testid="input-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Account Type</Label>
                  <Select value={userDetails.userType} onValueChange={(value: 'student' | 'shop_owner') => setUserDetails({ ...userDetails, userType: value })}>
                    <SelectTrigger data-testid="select-user-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="shop_owner">Shop Owner</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={sendOTPMutation.isPending || !contactValue || !userDetails.name}
                  data-testid="button-send-otp"
                >
                  {sendOTPMutation.isPending ? 'Sending...' : 'Send OTP'}
                </Button>
              </form>
            )}

            {step === 'otp' && (
              <form onSubmit={handleVerifyOTP} className="space-y-4">
                <div className="text-center space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Enter the 6-digit code sent to your {contactType}
                  </p>
                  <p className="font-medium">{contactValue}</p>
                </div>

                <div className="flex justify-center">
                  <InputOTP value={otp} onChange={setOtp} maxLength={6} data-testid="input-otp">
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>

                <div className="space-y-2">
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={verifyOTPMutation.isPending || otp.length !== 6}
                    data-testid="button-verify-otp"
                  >
                    {verifyOTPMutation.isPending ? 'Verifying...' : 'Verify & Continue'}
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="ghost" 
                    className="w-full" 
                    onClick={() => setStep('contact')}
                    data-testid="button-back"
                  >
                    Back
                  </Button>
                </div>

                <div className="text-center">
                  <Button
                    type="button"
                    variant="link"
                    className="text-sm"
                    onClick={() => sendOTPMutation.mutate(contactType === 'email' ? { email: contactValue } : { phone: contactValue })}
                    disabled={sendOTPMutation.isPending}
                    data-testid="button-resend-otp"
                  >
                    Resend OTP
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <Button variant="ghost" onClick={() => setLocation('/')} data-testid="button-home">
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}
