import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { auth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { Shop, Bike, BookingWithDetails } from "@/types";
import { Store, Calendar, Plus, Bike as BikeIcon } from "lucide-react";
import { useLocation } from "wouter";
import Navigation from "@/components/Navigation";
import { format } from "date-fns";

export default function ShopDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const user = auth.getUser();
  const [showAddBike, setShowAddBike] = useState(false);
  const [selectedShop, setSelectedShop] = useState('');

  const [bikeForm, setBikeForm] = useState({
    name: '',
    brand: '',
    model: '',
    vehicleType: 'bike' as 'bike' | 'scooter' | 'electric',
    engineCapacity: '',
    fuelType: '',
    transmission: '',
    hourlyRate: '',
    dailyRate: '',
    weeklyRate: '',
    imageUrl: '',
  });

  if (!user || user.userType !== 'shop_owner') {
    setLocation('/login');
    return null;
  }

  const { data: shops, isLoading: shopsLoading } = useQuery<Shop[]>({
    queryKey: ['/api/shops/my-shops'],
    enabled: !!auth.getToken(),
  });

  const { data: bookings, isLoading: bookingsLoading } = useQuery<BookingWithDetails[]>({
    queryKey: ['/api/bookings/shop', selectedShop],
    enabled: !!selectedShop,
  });

  const { data: bikes, isLoading: bikesLoading } = useQuery<Bike[]>({
    queryKey: ['/api/bikes/shop', selectedShop],
    enabled: !!selectedShop,
  });

  const addBikeMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/bikes', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Bike Added",
        description: "New bike has been added to your shop",
      });
      setShowAddBike(false);
      setBikeForm({
        name: '',
        brand: '',
        model: '',
        vehicleType: 'bike',
        engineCapacity: '',
        fuelType: '',
        transmission: '',
        hourlyRate: '',
        dailyRate: '',
        weeklyRate: '',
        imageUrl: '',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bikes/shop', selectedShop] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add bike",
        variant: "destructive",
      });
    },
  });

  const handleAddBike = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedShop) {
      toast({
        title: "No Shop Selected",
        description: "Please select a shop first",
        variant: "destructive",
      });
      return;
    }

    addBikeMutation.mutate({
      ...bikeForm,
      shopId: selectedShop,
      hourlyRate: parseFloat(bikeForm.hourlyRate),
      dailyRate: bikeForm.dailyRate ? parseFloat(bikeForm.dailyRate) : undefined,
      weeklyRate: bikeForm.weeklyRate ? parseFloat(bikeForm.weeklyRate) : undefined,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-accent text-accent-foreground';
      case 'active': return 'bg-primary text-primary-foreground';
      case 'completed': return 'bg-secondary text-secondary-foreground';
      case 'cancelled': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const totalRevenue = bookings?.filter(b => b.status === 'completed').reduce((sum, b) => sum + parseFloat(b.totalPrice), 0) || 0;
  const activeBookings = bookings?.filter(b => b.status === 'active' || b.status === 'confirmed') || [];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Shop Dashboard</h1>
            <p className="text-muted-foreground">Manage your bike rental business</p>
          </div>
          <Button onClick={() => setLocation('/shop-registration')} data-testid="button-add-shop">
            <Store className="w-4 h-4 mr-2" />
            Add New Shop
          </Button>
        </div>

        {shopsLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
            ))}
          </div>
        ) : shops && shops.length > 0 ? (
          <>
            {/* Shop Selection */}
            <div className="mb-8">
              <Label htmlFor="shopSelect" className="text-sm font-medium mb-2 block">Select Shop</Label>
              <Select value={selectedShop} onValueChange={setSelectedShop}>
                <SelectTrigger className="w-full max-w-md" data-testid="select-shop">
                  <SelectValue placeholder="Choose a shop to manage" />
                </SelectTrigger>
                <SelectContent>
                  {shops.map((shop) => (
                    <SelectItem key={shop.id} value={shop.id}>
                      {shop.name} - {shop.location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedShop && (
              <>
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Bikes</CardTitle>
                      <BikeIcon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-total-bikes">
                        {bikes?.length || 0}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Bookings</CardTitle>
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-active-rentals">
                        {activeBookings.length}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                      <Store className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-total-revenue">
                        ₹{totalRevenue}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Available Bikes</CardTitle>
                      <BikeIcon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-available-bikes">
                        {bikes?.filter(b => b.isAvailable).length || 0}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Management Tabs */}
                <Tabs defaultValue="bikes" className="space-y-6">
                  <TabsList>
                    <TabsTrigger value="bikes" data-testid="tab-bikes">My Bikes</TabsTrigger>
                    <TabsTrigger value="bookings" data-testid="tab-bookings">Bookings</TabsTrigger>
                  </TabsList>

                  <TabsContent value="bikes" className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Bike Fleet</h2>
                      <Dialog open={showAddBike} onOpenChange={setShowAddBike}>
                        <DialogTrigger asChild>
                          <Button data-testid="button-add-bike">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Bike
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Add New Bike</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={handleAddBike} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="brand">Brand</Label>
                                <Input
                                  id="brand"
                                  value={bikeForm.brand}
                                  onChange={(e) => setBikeForm({ ...bikeForm, brand: e.target.value })}
                                  required
                                  data-testid="input-brand"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="model">Model</Label>
                                <Input
                                  id="model"
                                  value={bikeForm.model}
                                  onChange={(e) => setBikeForm({ ...bikeForm, model: e.target.value })}
                                  required
                                  data-testid="input-model"
                                />
                              </div>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="name">Display Name</Label>
                              <Input
                                id="name"
                                value={bikeForm.name}
                                onChange={(e) => setBikeForm({ ...bikeForm, name: e.target.value })}
                                placeholder="e.g., Honda CB Shine 125"
                                required
                                data-testid="input-name"
                              />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Vehicle Type</Label>
                                <Select value={bikeForm.vehicleType} onValueChange={(value: 'bike' | 'scooter' | 'electric') => setBikeForm({ ...bikeForm, vehicleType: value })}>
                                  <SelectTrigger data-testid="select-vehicle-type">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="bike">Bike</SelectItem>
                                    <SelectItem value="scooter">Scooter</SelectItem>
                                    <SelectItem value="electric">Electric</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="engineCapacity">Engine Capacity</Label>
                                <Input
                                  id="engineCapacity"
                                  value={bikeForm.engineCapacity}
                                  onChange={(e) => setBikeForm({ ...bikeForm, engineCapacity: e.target.value })}
                                  placeholder="e.g., 125cc"
                                  data-testid="input-engine"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="fuelType">Fuel Type</Label>
                                <Input
                                  id="fuelType"
                                  value={bikeForm.fuelType}
                                  onChange={(e) => setBikeForm({ ...bikeForm, fuelType: e.target.value })}
                                  placeholder="e.g., Petrol, Electric"
                                  data-testid="input-fuel"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="transmission">Transmission</Label>
                                <Input
                                  id="transmission"
                                  value={bikeForm.transmission}
                                  onChange={(e) => setBikeForm({ ...bikeForm, transmission: e.target.value })}
                                  placeholder="e.g., Manual, Automatic"
                                  data-testid="input-transmission"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="hourlyRate">Hourly Rate (₹)</Label>
                                <Input
                                  id="hourlyRate"
                                  type="number"
                                  value={bikeForm.hourlyRate}
                                  onChange={(e) => setBikeForm({ ...bikeForm, hourlyRate: e.target.value })}
                                  required
                                  data-testid="input-hourly-rate"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="dailyRate">Daily Rate (₹)</Label>
                                <Input
                                  id="dailyRate"
                                  type="number"
                                  value={bikeForm.dailyRate}
                                  onChange={(e) => setBikeForm({ ...bikeForm, dailyRate: e.target.value })}
                                  data-testid="input-daily-rate"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="weeklyRate">Weekly Rate (₹)</Label>
                                <Input
                                  id="weeklyRate"
                                  type="number"
                                  value={bikeForm.weeklyRate}
                                  onChange={(e) => setBikeForm({ ...bikeForm, weeklyRate: e.target.value })}
                                  data-testid="input-weekly-rate"
                                />
                              </div>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="imageUrl">Image URL</Label>
                              <Input
                                id="imageUrl"
                                value={bikeForm.imageUrl}
                                onChange={(e) => setBikeForm({ ...bikeForm, imageUrl: e.target.value })}
                                placeholder="https://example.com/bike-image.jpg"
                                data-testid="input-image-url"
                              />
                            </div>

                            <div className="flex justify-end space-x-2">
                              <Button type="button" variant="outline" onClick={() => setShowAddBike(false)}>
                                Cancel
                              </Button>
                              <Button type="submit" disabled={addBikeMutation.isPending} data-testid="button-save-bike">
                                {addBikeMutation.isPending ? 'Adding...' : 'Add Bike'}
                              </Button>
                            </div>
                          </form>
                        </DialogContent>
                      </Dialog>
                    </div>

                    {bikesLoading ? (
                      <div className="space-y-4">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
                        ))}
                      </div>
                    ) : bikes && bikes.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {bikes.map((bike) => (
                          <Card key={bike.id} className="card-hover">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between mb-3">
                                <h3 className="font-semibold">{bike.brand} {bike.model}</h3>
                                <Badge className={bike.isAvailable ? 'bg-accent text-accent-foreground' : 'bg-destructive text-destructive-foreground'}>
                                  {bike.isAvailable ? 'Available' : 'Rented'}
                                </Badge>
                              </div>
                              <div className="space-y-2 text-sm text-muted-foreground">
                                <p>{bike.engineCapacity} • {bike.fuelType} • {bike.transmission}</p>
                                <p className="font-medium text-foreground">₹{bike.hourlyRate}/hour</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <Card>
                        <CardContent className="text-center py-12">
                          <h3 className="text-lg font-semibold mb-2">No Bikes Added</h3>
                          <p className="text-muted-foreground mb-4">
                            Add your first bike to start accepting bookings
                          </p>
                          <Button onClick={() => setShowAddBike(true)} data-testid="button-add-first-bike">
                            Add Your First Bike
                          </Button>
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>

                  <TabsContent value="bookings" className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Recent Bookings</h2>
                    </div>

                    {bookingsLoading ? (
                      <div className="space-y-4">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
                        ))}
                      </div>
                    ) : bookings && bookings.length > 0 ? (
                      <div className="space-y-4">
                        {bookings.map((booking) => (
                          <Card key={booking.id}>
                            <CardContent className="p-6">
                              <div className="flex items-start justify-between mb-4">
                                <div className="space-y-1">
                                  <h3 className="font-semibold">
                                    {booking.bike.brand} {booking.bike.model}
                                  </h3>
                                  <p className="text-sm text-muted-foreground">
                                    Booked by: {booking.user?.name}
                                  </p>
                                </div>
                                <Badge className={getStatusColor(booking.status)}>
                                  {booking.status}
                                </Badge>
                              </div>

                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div>
                                  <p className="text-sm text-muted-foreground">Start Date</p>
                                  <p className="font-medium">{format(new Date(booking.startDate), 'MMM dd, yyyy')}</p>
                                  <p className="text-sm">{format(new Date(booking.startDate), 'hh:mm a')}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">End Date</p>
                                  <p className="font-medium">{format(new Date(booking.endDate), 'MMM dd, yyyy')}</p>
                                  <p className="text-sm">{format(new Date(booking.endDate), 'hh:mm a')}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Duration</p>
                                  <p className="font-medium">{booking.totalHours} hours</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Revenue</p>
                                  <p className="font-medium">₹{booking.totalPrice}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <Card>
                        <CardContent className="text-center py-12">
                          <h3 className="text-lg font-semibold mb-2">No Bookings Yet</h3>
                          <p className="text-muted-foreground">
                            Your bookings will appear here once customers start renting your bikes
                          </p>
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>
                </Tabs>
              </>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <h3 className="text-lg font-semibold mb-2">No Shops Registered</h3>
              <p className="text-muted-foreground mb-4">
                Register your first shop to start managing bike rentals
              </p>
              <Button onClick={() => setLocation('/shop-registration')} data-testid="button-register-first-shop">
                Register Your First Shop
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
