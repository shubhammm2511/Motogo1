import { Smartphone, Clock, IndianRupee } from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Smartphone,
      title: "OTP Verification",
      description: "Secure login with OTP - no passwords to remember. Just your phone number or email.",
      color: "bg-primary",
      textColor: "text-primary-foreground"
    },
    {
      icon: Clock,
      title: "Instant Booking",
      description: "Book bikes instantly with real-time availability. No waiting, no paperwork hassles.",
      color: "bg-secondary",
      textColor: "text-secondary-foreground"
    },
    {
      icon: IndianRupee,
      title: "Student Pricing",
      description: "Special rates for UPES students. Affordable hourly and daily rental options.",
      color: "bg-accent",
      textColor: "text-accent-foreground"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Choose MotoGo?</h2>
          <p className="text-lg text-muted-foreground">Experience hassle-free bike rentals designed for students</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6">
              <div className={`w-16 h-16 ${feature.color} rounded-full flex items-center justify-center mx-auto mb-6`}>
                <feature.icon className={`w-8 h-8 ${feature.textColor}`} />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
