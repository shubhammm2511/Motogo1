import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Bike, Smartphone, Store } from "lucide-react";

export default function Footer() {
  const [, setLocation] = useLocation();

  return (
    <>
      {/* CTA Section */}
      <section className="py-16 hero-gradient">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Ready to Start Your Journey?</h2>
          <p className="text-lg text-foreground/80 mb-8">Join thousands of UPES students who trust MotoGo for their daily commute</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-secondary text-secondary-foreground hover:bg-accent px-8 py-3"
              onClick={() => setLocation('/browse')}
              data-testid="button-browse-cta"
            >
              <Smartphone className="w-4 h-4 mr-2" />
              Browse Bikes
            </Button>
            <Button 
              variant="outline"
              className="bg-white text-foreground hover:bg-gray-50 px-8 py-3"
              onClick={() => setLocation('/shop-registration')}
              data-testid="button-partner-cta"
            >
              <Store className="w-4 h-4 mr-2" />
              Become a Partner
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Bike className="text-primary-foreground text-lg" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">MotoGo</h3>
                  <p className="text-sm opacity-80">Your Ride, Your Way</p>
                </div>
              </div>
              <p className="text-background/80 mb-4 max-w-md">
                Connecting UPES students with reliable, affordable bike rentals near campus. Your trusted partner for daily commutes and weekend adventures.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-8 h-8 bg-background/10 rounded-full flex items-center justify-center hover:bg-background/20 transition-colors">
                  <i className="fab fa-facebook-f text-sm"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-background/10 rounded-full flex items-center justify-center hover:bg-background/20 transition-colors">
                  <i className="fab fa-twitter text-sm"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-background/10 rounded-full flex items-center justify-center hover:bg-background/20 transition-colors">
                  <i className="fab fa-instagram text-sm"></i>
                </a>
              </div>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button 
                    onClick={() => setLocation('/browse')}
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    Browse Bikes
                  </button>
                </li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">How it Works</a></li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Pricing</a></li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Student Offers</a></li>
              </ul>
            </div>
            
            {/* Support */}
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Help Center</a></li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Safety Guidelines</a></li>
                <li><a href="#" className="text-background/80 hover:text-background transition-colors">Terms & Privacy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-background/20 mt-8 pt-8 text-center">
            <p className="text-background/60 text-sm">
              © 2024 MotoGo. All rights reserved. Made with ❤️ for UPES students.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
