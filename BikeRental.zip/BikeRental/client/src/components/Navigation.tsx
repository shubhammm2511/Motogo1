import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { auth } from "@/lib/auth";
import { Bike, Menu, User, LogOut } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navigation() {
  const [, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const user = auth.getUser();
  const isAuthenticated = auth.isAuthenticated();

  const handleLogout = () => {
    auth.logout();
    setLocation('/');
  };

  const NavLinks = ({ isMobile = false, onClose = () => {} }) => (
    <>
      <button 
        onClick={() => { setLocation('/browse'); onClose(); }}
        className="text-foreground hover:text-primary font-medium transition-colors"
        data-testid="nav-browse"
      >
        Browse Bikes
      </button>
      <button 
        onClick={() => { setLocation('/how-it-works'); onClose(); }}
        className="text-foreground hover:text-primary font-medium transition-colors"
        data-testid="nav-how-it-works"
      >
        How it Works
      </button>
      <button 
        onClick={() => { setLocation('/pricing'); onClose(); }}
        className="text-foreground hover:text-primary font-medium transition-colors"
        data-testid="nav-pricing"
      >
        Pricing
      </button>
      <button 
        onClick={() => { setLocation('/student-offers'); onClose(); }}
        className="text-foreground hover:text-primary font-medium transition-colors"
        data-testid="nav-student-offers"
      >
        Student Offers
      </button>
      <button 
        onClick={() => { setLocation('/shop-registration'); onClose(); }}
        className="text-foreground hover:text-primary font-medium transition-colors"
        data-testid="nav-partner"
      >
        Become a Partner
      </button>
      
      {!isAuthenticated ? (
        <div className={`flex ${isMobile ? 'flex-col' : 'items-center'} space-${isMobile ? 'y' : 'x'}-3`}>
          <Button 
            variant="ghost" 
            onClick={() => { setLocation('/login'); onClose(); }}
            data-testid="nav-signin"
          >
            Sign In
          </Button>
          <Button 
            onClick={() => { setLocation('/login'); onClose(); }}
            className="bg-secondary text-secondary-foreground hover:bg-accent"
            data-testid="nav-join"
          >
            Join MotoGo
          </Button>
        </div>
      ) : (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center space-x-2" data-testid="nav-user-menu">
              <User className="w-4 h-4" />
              <span>{user?.name || 'User'}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem 
              onClick={() => { 
                if (user?.userType === 'shop_owner') {
                  setLocation('/shop-dashboard');
                } else {
                  setLocation('/dashboard');
                }
                onClose();
              }}
              data-testid="nav-dashboard"
            >
              Dashboard
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} data-testid="nav-logout">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </>
  );

  return (
    <nav className="bg-white shadow-sm border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <button 
            onClick={() => setLocation('/')}
            className="flex items-center space-x-3"
            data-testid="nav-logo"
          >
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Bike className="text-primary-foreground text-lg" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">MotoGo</h1>
              <p className="text-xs text-muted-foreground -mt-1">Your Ride, Your Way</p>
            </div>
          </button>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLinks />
          </div>
          
          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" data-testid="nav-mobile-toggle">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col space-y-6 mt-6">
                <NavLinks isMobile onClose={() => setIsOpen(false)} />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
