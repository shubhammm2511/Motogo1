import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { MapPin, Search, Calendar } from "lucide-react";

export default function HeroSection() {
  const [, setLocation] = useLocation();
  const [searchData, setSearchData] = useState({
    location: '',
    vehicleType: 'all',
    date: '',
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    
    if (searchData.location) params.append('location', searchData.location);
    if (searchData.vehicleType && searchData.vehicleType !== 'all') params.append('vehicleType', searchData.vehicleType);
    if (searchData.date) params.append('date', searchData.date);
    
    setLocation(`/browse?${params.toString()}`);
  };

  return (
    <section className="hero-gradient py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Find Your Perfect Ride at <span className="text-accent">UPES Campus</span>
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto mb-8">
            Discover affordable bike and scooter rentals near Bidholi and Kandoli campus. Book instantly with OTP verification.
          </p>
          
          {/* Location Badges */}
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            <Badge className="location-badge text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium">
              <MapPin className="w-4 h-4 mr-2" />
              UPES Bidholi
            </Badge>
            <Badge className="location-badge text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium">
              <MapPin className="w-4 h-4 mr-2" />
              UPES Kandoli
            </Badge>
          </div>
        </div>
        
        {/* Search Form */}
        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 max-w-5xl mx-auto">
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-6">
            {/* Location */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground block">Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Select value={searchData.location} onValueChange={(value) => setSearchData({ ...searchData, location: value })}>
                  <SelectTrigger className="pl-10" data-testid="select-hero-location">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bidholi">UPES Bidholi</SelectItem>
                    <SelectItem value="kandoli">UPES Kandoli</SelectItem>
                    <SelectItem value="near_campus">Near Campus</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Vehicle Type */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground block">Vehicle Type</label>
              <div className="relative">
                <Select value={searchData.vehicleType} onValueChange={(value) => setSearchData({ ...searchData, vehicleType: value })}>
                  <SelectTrigger data-testid="select-hero-vehicle">
                    <SelectValue placeholder="All Vehicles" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Vehicles</SelectItem>
                    <SelectItem value="bike">Bikes</SelectItem>
                    <SelectItem value="scooter">Scooters</SelectItem>
                    <SelectItem value="electric">Electric Bikes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Date */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground block">Rental Date</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="date"
                  className="pl-10"
                  value={searchData.date}
                  onChange={(e) => setSearchData({ ...searchData, date: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                  data-testid="input-hero-date"
                />
              </div>
            </div>
            
            {/* Search Button */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-transparent block">Search</label>
              <Button 
                type="submit"
                className="w-full bg-secondary text-secondary-foreground hover:bg-accent h-12 flex items-center justify-center"
                data-testid="button-hero-search"
              >
                <Search className="w-4 h-4 mr-2" />
                Find Bikes
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
