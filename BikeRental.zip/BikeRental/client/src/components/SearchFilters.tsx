import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SearchFilters as SearchFiltersType } from "@/types";
import { X } from "lucide-react";

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onFiltersChange: (filters: SearchFiltersType) => void;
}

export default function SearchFilters({ filters, onFiltersChange }: SearchFiltersProps) {
  const updateFilter = (key: keyof SearchFiltersType, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const clearFilters = () => {
    onFiltersChange({
      location: 'all',
      vehicleType: 'all', 
      minPrice: '',
      maxPrice: '',
      available: true,
    });
  };

  const hasActiveFilters = (filters.location && filters.location !== 'all') || (filters.vehicleType && filters.vehicleType !== 'all') || filters.minPrice || filters.maxPrice;

  return (
    <Card className="mb-8">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Filter Results</CardTitle>
          {hasActiveFilters && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearFilters}
              data-testid="button-clear-filters"
            >
              <X className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Location Filter */}
          <div className="space-y-2">
            <Label>Location</Label>
            <Select 
              value={filters.location} 
              onValueChange={(value) => updateFilter('location', value)}
            >
              <SelectTrigger data-testid="select-filter-location">
                <SelectValue placeholder="All Locations" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="bidholi">UPES Bidholi</SelectItem>
                <SelectItem value="kandoli">UPES Kandoli</SelectItem>
                <SelectItem value="near_campus">Near Campus</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Vehicle Type Filter */}
          <div className="space-y-2">
            <Label>Vehicle Type</Label>
            <Select 
              value={filters.vehicleType} 
              onValueChange={(value) => updateFilter('vehicleType', value)}
            >
              <SelectTrigger data-testid="select-filter-vehicle">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="bike">Bikes</SelectItem>
                <SelectItem value="scooter">Scooters</SelectItem>
                <SelectItem value="electric">Electric</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Price Range */}
          <div className="space-y-2">
            <Label>Min Price (₹/hour)</Label>
            <Input
              type="number"
              placeholder="Min price"
              value={filters.minPrice}
              onChange={(e) => updateFilter('minPrice', e.target.value)}
              data-testid="input-min-price"
            />
          </div>

          <div className="space-y-2">
            <Label>Max Price (₹/hour)</Label>
            <Input
              type="number"
              placeholder="Max price"
              value={filters.maxPrice}
              onChange={(e) => updateFilter('maxPrice', e.target.value)}
              data-testid="input-max-price"
            />
          </div>
        </div>

        {/* Active Filters Display */}
        {hasActiveFilters && (
          <div className="mt-4 pt-4 border-t">
            <div className="flex flex-wrap gap-2">
              {filters.location && filters.location !== 'all' && (
                <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
                  Location: {filters.location}
                  <button 
                    onClick={() => updateFilter('location', 'all')}
                    className="ml-2 hover:text-primary/70"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              {filters.vehicleType && filters.vehicleType !== 'all' && (
                <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
                  Type: {filters.vehicleType}
                  <button 
                    onClick={() => updateFilter('vehicleType', 'all')}
                    className="ml-2 hover:text-primary/70"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              {filters.minPrice && (
                <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
                  Min: ₹{filters.minPrice}
                  <button 
                    onClick={() => updateFilter('minPrice', '')}
                    className="ml-2 hover:text-primary/70"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              {filters.maxPrice && (
                <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
                  Max: ₹{filters.maxPrice}
                  <button 
                    onClick={() => updateFilter('maxPrice', '')}
                    className="ml-2 hover:text-primary/70"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
