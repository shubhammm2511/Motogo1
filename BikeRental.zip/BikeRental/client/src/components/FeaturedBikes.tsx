import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { BikeWithShop } from "@/types";
import BikeCard from "./BikeCard";

export default function FeaturedBikes() {
  const [, setLocation] = useLocation();
  const [activeFilter, setActiveFilter] = useState('');

  const { data: bikes, isLoading } = useQuery<BikeWithShop[]>({
    queryKey: ['/api/bikes', activeFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (activeFilter) {
        if (activeFilter === 'under50') {
          params.append('maxPrice', '50');
        } else {
          params.append('vehicleType', activeFilter);
        }
      }
      params.append('available', 'true');
      
      const response = await fetch(`/api/bikes?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch bikes');
      return response.json();
    },
  });

  const filters = [
    { key: '', label: 'All' },
    { key: 'bike', label: 'Bikes' },
    { key: 'scooter', label: 'Scooters' },
    { key: 'electric', label: 'Electric' },
    { key: 'under50', label: 'Under ₹50/hr' },
  ];

  if (isLoading) {
    return (
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <Skeleton className="h-8 w-48 mb-4" />
              <Skeleton className="h-4 w-64" />
            </div>
            <Skeleton className="h-6 w-32 hidden md:block" />
          </div>
          
          <div className="flex flex-wrap gap-3 mb-8">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-8 w-20" />
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-48 w-full rounded-2xl" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-10 w-full" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Available Bikes</h2>
            <p className="text-lg text-muted-foreground">Choose from a wide variety of bikes and scooters</p>
          </div>
          <Button 
            variant="ghost"
            className="hidden md:block text-secondary hover:text-accent"
            onClick={() => setLocation('/browse')}
            data-testid="button-view-all"
          >
            View All Bikes →
          </Button>
        </div>
        
        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-8">
          {filters.map((filter) => (
            <Button
              key={filter.key}
              variant={activeFilter === filter.key ? "default" : "outline"}
              size="sm"
              className={activeFilter === filter.key ? "bg-secondary text-secondary-foreground" : ""}
              onClick={() => setActiveFilter(filter.key)}
              data-testid={`filter-${filter.key || 'all'}`}
            >
              {filter.label}
            </Button>
          ))}
        </div>
        
        {bikes && bikes.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {bikes.slice(0, 8).map((bike) => (
                <BikeCard key={bike.id} bike={bike} />
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Button 
                className="bg-secondary text-secondary-foreground hover:bg-accent px-8 py-3"
                onClick={() => setLocation('/browse')}
                data-testid="button-view-all-center"
              >
                View All {bikes.length}+ Bikes
              </Button>
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold text-foreground mb-2">No Bikes Available</h3>
            <p className="text-muted-foreground mb-4">
              {activeFilter ? 'Try adjusting your filters' : 'Check back later for available bikes'}
            </p>
            {activeFilter && (
              <Button onClick={() => setActiveFilter('')} data-testid="button-clear-filters">
                Clear Filters
              </Button>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
