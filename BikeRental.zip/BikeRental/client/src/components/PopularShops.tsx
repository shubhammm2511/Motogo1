import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { ShopWithStats } from "@/types";
import { MapPin, Star } from "lucide-react";

export default function PopularShops() {
  const [, setLocation] = useLocation();

  const { data: shops, isLoading } = useQuery<ShopWithStats[]>({
    queryKey: ['/api/shops'],
    queryFn: async () => {
      const response = await fetch('/api/shops');
      if (!response.ok) throw new Error('Failed to fetch shops');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Skeleton className="h-8 w-64 mx-auto mb-4" />
            <Skeleton className="h-4 w-48 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-48 w-full rounded-2xl" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-10 w-full" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Popular Shops Near Campus</h2>
          <p className="text-lg text-muted-foreground">Trusted by thousands of UPES students</p>
        </div>
        
        {shops && shops.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {shops.slice(0, 6).map((shop) => (
              <Card key={shop.id} className="card-hover overflow-hidden">
                <CardContent className="p-0">
                  <img 
                    src="https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=200" 
                    alt={`${shop.name} bike rental shop`}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xl font-bold text-card-foreground">{shop.name}</h3>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium text-card-foreground">
                          {parseFloat(shop.rating || '0').toFixed(1)}
                        </span>
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm mb-3 flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {shop.location === 'bidholi' ? 'UPES Bidholi Campus' : 
                       shop.location === 'kandoli' ? 'UPES Kandoli Campus' : 'Near Campus'}
                    </p>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-muted-foreground">
                        {shop.bikeCount || 0}+ Bikes Available
                      </span>
                      <span className="text-sm font-medium text-secondary">From ₹50/hr</span>
                    </div>
                    <div className="flex space-x-2 mb-4">
                      <Badge variant="secondary" className="text-xs">Bikes</Badge>
                      <Badge variant="secondary" className="text-xs">Scooters</Badge>
                      <Badge className="bg-accent/10 text-accent text-xs">Open Now</Badge>
                    </div>
                    <Button 
                      className="w-full bg-secondary text-secondary-foreground hover:bg-accent"
                      onClick={() => setLocation(`/browse?location=${shop.location}`)}
                      data-testid={`button-view-shop-${shop.id}`}
                    >
                      View Bikes
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold text-foreground mb-2">No Shops Available</h3>
            <p className="text-muted-foreground mb-4">
              Be the first shop owner to join MotoGo!
            </p>
            <Button onClick={() => setLocation('/login')} data-testid="button-become-partner">
              Become a Partner
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
