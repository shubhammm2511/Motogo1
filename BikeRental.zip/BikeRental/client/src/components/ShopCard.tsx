import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ShopWithStats } from "@/types";
import { Star, MapPin } from "lucide-react";

interface ShopCardProps {
  shop: ShopWithStats;
}

export default function ShopCard({ shop }: ShopCardProps) {
  const [, setLocation] = useLocation();

  const handleViewShop = () => {
    setLocation(`/browse?shopId=${shop.id}`);
  };

  const getLocationLabel = (location: string) => {
    switch (location) {
      case 'bidholi':
        return 'UPES Bidholi Campus';
      case 'kandoli':
        return 'UPES Kandoli Campus';
      default:
        return 'Near Campus';
    }
  };

  return (
    <Card className="card-hover overflow-hidden">
      <CardContent className="p-0">
        <img 
          src="https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=200" 
          alt={`${shop.name} bike rental shop`}
          className="w-full h-48 object-cover"
        />
        <div className="p-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xl font-bold text-card-foreground">{shop.name}</h3>
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium text-card-foreground">
                {parseFloat(shop.rating || '0').toFixed(1)}
              </span>
            </div>
          </div>
          
          <p className="text-muted-foreground text-sm mb-3 flex items-center">
            <MapPin className="w-4 h-4 mr-1" />
            {getLocationLabel(shop.location)}
          </p>
          
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-muted-foreground">
              {shop.bikeCount || 0}+ Bikes Available
            </span>
            <span className="text-sm font-medium text-secondary">From ₹50/hr</span>
          </div>
          
          <div className="flex space-x-2 mb-4">
            <Badge variant="secondary" className="text-xs">Bikes</Badge>
            <Badge variant="secondary" className="text-xs">Scooters</Badge>
            <Badge className="bg-accent/10 text-accent text-xs">
              {shop.isActive ? 'Open Now' : 'Closed'}
            </Badge>
          </div>
          
          <Button 
            className="w-full bg-secondary text-secondary-foreground hover:bg-accent"
            onClick={handleViewShop}
            data-testid={`button-view-shop-${shop.id}`}
          >
            View Bikes
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
