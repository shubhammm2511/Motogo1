import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { auth } from "@/lib/auth";
import { useLocation } from "wouter";

interface OTPModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OTPModal({ isOpen, onClose }: OTPModalProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState<'contact' | 'otp'>('contact');
  const [contactType, setContactType] = useState<'email' | 'phone'>('email');
  const [contactValue, setContactValue] = useState('');
  const [otp, setOtp] = useState('');
  const [userDetails, setUserDetails] = useState({
    name: '',
    userType: 'student' as 'student' | 'shop_owner'
  });

  const sendOTPMutation = useMutation({
    mutationFn: async (data: { email?: string; phone?: string }) => {
      const response = await apiRequest('POST', '/api/auth/send-otp', data);
      return response.json();
    },
    onSuccess: () => {
      setStep('otp');
      toast({
        title: "OTP Sent",
        description: `Verification code sent to your ${contactType}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send OTP",
        variant: "destructive",
      });
    },
  });

  const verifyOTPMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/auth/verify-otp', data);
      return response.json();
    },
    onSuccess: (data) => {
      auth.setToken(data.token);
      auth.setUser(data.user);
      toast({
        title: "Welcome!",
        description: "Successfully logged in",
      });
      onClose();
      
      if (data.user.userType === 'shop_owner') {
        setLocation('/shop-dashboard');
      } else {
        setLocation('/dashboard');
      }
    },
    onError: (error: any) => {
      toast({
        title: "Invalid OTP",
        description: error.message || "Please check your verification code",
        variant: "destructive",
      });
    },
  });

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactValue || !userDetails.name) return;

    const data = contactType === 'email' 
      ? { email: contactValue }
      : { phone: contactValue };
    
    sendOTPMutation.mutate(data);
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;

    const data = {
      [contactType]: contactValue,
      otp,
      name: userDetails.name,
      userType: userDetails.userType,
    };

    verifyOTPMutation.mutate(data);
  };

  const resetForm = () => {
    setStep('contact');
    setContactValue('');
    setOtp('');
    setUserDetails({ name: '', userType: 'student' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) { onClose(); resetForm(); } }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {step === 'contact' ? 'Welcome to MotoGo' : 'Verify Your Account'}
          </DialogTitle>
        </DialogHeader>
        
        {step === 'contact' && (
          <form onSubmit={handleSendOTP} className="space-y-4">
            <div className="space-y-2">
              <Label>Contact Method</Label>
              <Select value={contactType} onValueChange={(value: 'email' | 'phone') => setContactType(value)}>
                <SelectTrigger data-testid="select-otp-contact-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="phone">Phone</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{contactType === 'email' ? 'Email Address' : 'Phone Number'}</Label>
              <Input
                type={contactType === 'email' ? 'email' : 'tel'}
                placeholder={contactType === 'email' ? 'your.email@upes.ac.in' : '+91 9876543210'}
                value={contactValue}
                onChange={(e) => setContactValue(e.target.value)}
                required
                data-testid="input-otp-contact"
              />
            </div>

            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                type="text"
                placeholder="Enter your full name"
                value={userDetails.name}
                onChange={(e) => setUserDetails({ ...userDetails, name: e.target.value })}
                required
                data-testid="input-otp-name"
              />
            </div>

            <div className="space-y-2">
              <Label>Account Type</Label>
              <Select value={userDetails.userType} onValueChange={(value: 'student' | 'shop_owner') => setUserDetails({ ...userDetails, userType: value })}>
                <SelectTrigger data-testid="select-otp-user-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="shop_owner">Shop Owner</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={sendOTPMutation.isPending || !contactValue || !userDetails.name}
              data-testid="button-otp-send"
            >
              {sendOTPMutation.isPending ? 'Sending...' : 'Send OTP'}
            </Button>
          </form>
        )}

        {step === 'otp' && (
          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                Enter the 6-digit code sent to your {contactType}
              </p>
              <p className="font-medium">{contactValue}</p>
            </div>

            <div className="flex justify-center">
              <InputOTP value={otp} onChange={setOtp} maxLength={6} data-testid="input-otp-code">
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <div className="space-y-2">
              <Button 
                type="submit" 
                className="w-full" 
                disabled={verifyOTPMutation.isPending || otp.length !== 6}
                data-testid="button-otp-verify"
              >
                {verifyOTPMutation.isPending ? 'Verifying...' : 'Verify & Continue'}
              </Button>
              
              <Button 
                type="button" 
                variant="ghost" 
                className="w-full" 
                onClick={() => setStep('contact')}
                data-testid="button-otp-back"
              >
                Back
              </Button>
            </div>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                className="text-sm"
                onClick={() => sendOTPMutation.mutate(contactType === 'email' ? { email: contactValue } : { phone: contactValue })}
                disabled={sendOTPMutation.isPending}
                data-testid="button-otp-resend"
              >
                Resend OTP
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
