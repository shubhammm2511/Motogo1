import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BikeWithShop } from "@/types";
import { Star, MapPin } from "lucide-react";

interface BikeCardProps {
  bike: BikeWithShop;
}

export default function BikeCard({ bike }: BikeCardProps) {
  const [, setLocation] = useLocation();

  const handleBookNow = () => {
    setLocation(`/booking/${bike.id}`);
  };

  return (
    <Card className="card-hover overflow-hidden">
      <CardContent className="p-0">
        <img 
          src={bike.imageUrl || "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"} 
          alt={`${bike.brand} ${bike.model} available for rent`}
          className="w-full h-48 object-cover"
        />
        <div className="p-5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-card-foreground">{bike.brand} {bike.model}</h3>
            <Badge className={bike.isAvailable ? 'bg-accent/10 text-accent' : 'bg-destructive/10 text-destructive'}>
              {bike.isAvailable ? 'Available' : 'Rented'}
            </Badge>
          </div>
          
          <p className="text-sm text-muted-foreground mb-3">
            {bike.engineCapacity} • {bike.fuelType} • {bike.transmission}
          </p>
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium">{parseFloat(bike.rating || '0').toFixed(1)}</span>
              <span className="text-xs text-muted-foreground">({bike.totalReviews || 0})</span>
            </div>
            <span className="text-sm text-muted-foreground">{bike.shop.name}</span>
          </div>
          
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-lg font-bold text-card-foreground">₹{bike.hourlyRate}</span>
              <span className="text-sm text-muted-foreground">/hour</span>
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <MapPin className="w-3 h-3 mr-1" />
              <span>
                {bike.shop.location === 'bidholi' ? 'Bidholi' : 
                 bike.shop.location === 'kandoli' ? 'Kandoli' : 'Near Campus'}
              </span>
            </div>
          </div>
          
          <Button 
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handleBookNow}
            disabled={!bike.isAvailable}
            data-testid={`button-book-${bike.id}`}
          >
            {bike.isAvailable ? 'Book Now' : 'Not Available'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
